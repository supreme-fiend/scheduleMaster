function loadAllocationTable() {

	Allocation.set("9A","MA","Ahalya",7); // 9 Maths
	Allocation.set("7A","MA","Ahalya",7); // 7 Maths
	Allocation.set("8A","MA","Ahalya",7); // 8 Maths
	Allocation.set("6A","MA","Ahalya",7); // 6 Maths
	Allocation.set("9A","EN","Draupadi",7); // 9 English
	Allocation.set("7A","EN","Draupadi",6); // 7 English
	Allocation.set("8A","EN","Draupadi",6); // 8 English
	Allocation.set("6A","EN","Draupadi",6); // 6 English
	Allocation.set("9A","HI","Seetha",6); // 9 SS
	Allocation.set("7A","HI","Seetha",6); // 7 SS
	Allocation.set("8A","HI","Seetha",6); // 8 SS
	Allocation.set("6A","HI","Seetha",6); // 6 SS
	Allocation.set("9A","PH","Tara",4); // 9 Physics
	Allocation.set("7A","PH","Tara",3); // 7 Physics
	Allocation.set("8A","PH","Tara",3); // 8 Physics
	Allocation.set("6A","PH","Tara",3); // 6 Physics
	Allocation.set("9A","CH","Madodri",4); // 9 Chemistry
	Allocation.set("7A","CH","Madodri",3); // 7 Chemistry
	Allocation.set("8A","CH","Madodri",3); // 8 Chemistry
	Allocation.set("6A","CH","Madodri",3); // 6 Chemistry
	Allocation.set("9A","BI","Kunti",4); // 9 Biology
	Allocation.set("7A","BI","Kunti",3); // 7 Biology
	Allocation.set("8A","BI","Kunti",3); // 8 Biology
	Allocation.set("6A","BI","Kunti",3); // 6 Biology
	Allocation.set("9A","LA","Madri",3); // 9 Hindi
	Allocation.set("7A","LA","Madri",7); // 7 Hindi
	Allocation.set("8A","LA","Madri",7); // 8 Hindi
	Allocation.set("6A","LA","Madri",7); // 6 Hindi 
}

function loadInitValues() {
	set("9A","Monday",1,"MA");
	set("8A","Tuesday",1,"MA");
	set("7A","Wednesday",1,"MA");
	set("6A","Thursday",1,"MA");
}